/**
 * @file image.cpp
 * @brief Fichero con definiciones para los métodos primitivos de la clase Image
 *
 */

#include <cstring>
#include <cassert>
#include <iostream>
#include <cmath>
#include <image.h>
#include <imageIO.h>

using namespace std;

/********************************
      FUNCIONES PRIVADAS
********************************/
void Image::Allocate(int nrows, int ncols, byte * buffer){
    rows = nrows;
    cols = ncols;

    img = new byte * [rows];

    if (buffer != 0)
        img[0] = buffer;
    else
        img[0] = new byte [rows * cols];

    for (int i=1; i < rows; i++)
        img[i] = img[i-1] + cols;
}

// Función auxiliar para inicializar imágenes con valores por defecto o a partir de un buffer de datos
void Image::Initialize (int nrows, int ncols, byte * buffer){
    if ((nrows == 0) || (ncols == 0)){
        rows = cols = 0;
        img = 0;
    }
    else Allocate(nrows, ncols, buffer);
}

// Función auxiliar para copiar objetos Imagen

void Image::Copy(const Image & orig){
    Initialize(orig.rows,orig.cols);
    for (int k=0; k<rows*cols;k++)
        set_pixel(k,orig.get_pixel(k));
}

// Función auxiliar para destruir objetos Imagen
bool Image::Empty() const{
    return (rows == 0) || (cols == 0);
}

void Image::Destroy(){
    if (!Empty()){
        delete [] img[0];
        delete [] img;
    }
}

LoadResult Image::LoadFromPGM(const char * file_path){
    if (ReadImageKind(file_path) != IMG_PGM)
        return LoadResult::NOT_PGM;

    byte * buffer = ReadPGMImage(file_path, rows, cols);
    if (!buffer)
        return LoadResult::READING_ERROR;

    Initialize(rows, cols, buffer);
    return LoadResult::SUCCESS;
}

/********************************
       FUNCIONES PÚBLICAS
********************************/

// Constructor por defecto

Image::Image(){
    Initialize();
}

// Constructores con parámetros
Image::Image (int nrows, int ncols, byte value){
    Initialize(nrows, ncols);
    for (int k=0; k<rows*cols; k++) set_pixel(k,value);
}

bool Image::Load (const char * file_path) {
    Destroy();
    return LoadFromPGM(file_path) == LoadResult::SUCCESS;
}

// Constructor de copias

Image::Image (const Image & orig){
    assert (this != &orig);
    Copy(orig);
}

// Destructor

Image::~Image(){
    Destroy();
}

// Operador de Asignación

Image & Image::operator= (const Image & orig){
    if (this != &orig){
        Destroy();
        Copy(orig);
    }
    return *this;
}

// Métodos de acceso a los campos de la clase

int Image::get_rows() const {
    return rows;
}

int Image::get_cols() const {
    return cols;
}

int Image::size() const{
    return get_rows()*get_cols();
}

// Métodos básicos de edición de imágenes
void Image::set_pixel (int i, int j, byte value) {
    img[i][j] = value;
}
byte Image::get_pixel (int i, int j) const {
    return img[i][j];
}

/*
// This doesn't work if representation changes
void Image::set_pixel (int k, byte value) {
    // TODO this makes assumptions about the internal representation
    // TODO Can you reuse set_pixel(i,j,value)?
    img[0][k] = value;
}

// This doesn't work if representation changes
byte Image::get_pixel (int k) const {
    // TODO this makes assumptions about the internal representation
    // TODO Can you reuse get_pixel(i,j)?
    return img[0][k];
}*/

// This doesn't work if representation changes
void Image::set_pixel (int k, byte value) {
int i, j;
    double pos = k;

    i = floor((pos/(double)get_cols()));
    j = (k % (get_cols()));

    set_pixel(i,j,value);
}

// This doesn't work if representation changes
byte Image::get_pixel (int k) const {
   int i, j;
    double pos = k;

    i = floor((pos/(double)get_cols()));
    j = (k % (get_cols()));

    return get_pixel(i,j);
}

// Métodos para almacenar y cargar imagenes en disco
bool Image::Save (const char * file_path) const {
    // TODO this makes assumptions about the internal representation
    byte * p = new byte[size()];
    for (int i = 0; i < size(); i++) {
            p[i] = get_pixel(i);
    }

    return WritePGMImage(file_path, p, rows, cols);
}

Image Image::Crop(int nrow, int ncol, int height, int width) const{
    Image crop(height, width); 
    for(int i = 0; i < height; i++){
	for(int j = 0; j < width; j++){
            byte valor = this->get_pixel(nrow + i , ncol + j); 
            crop.set_pixel(i,j,valor);
	}
    }

    return crop; 
}

//metodo para ampliar la imagen por 2
Image Image::Zoom2X() const{
    
    int filas = this->get_rows()*2-1;
    int columnas = this->get_cols()*2-1; 
    Image zoom(filas, columnas); 
    
    int x = 0; 
    int y = 0; 
    
    for(int i = 0; i < zoom.get_rows(); i++){ 
        for(int j = 0; j < zoom.get_cols(); j++){ 
            if(i%2 == 0 && j%2 == 0){
                byte aux = this->get_pixel(x,y); 
                zoom.set_pixel(i,j,aux);
            }else if(i%2 == 0 && j%2 != 0){
                double aux = (this->get_pixel(x,y)+this->get_pixel(x,y+1));
                aux = round(aux/2);
                zoom.set_pixel(i,j,aux); 
                y++;  
            }else if(i%2 != 0 && j%2 == 0){
                double aux = (this->get_pixel(x,y)+this->get_pixel(x+1,y));
                aux = round(aux/2); 
                zoom.set_pixel(i,j,aux); 
                y++;  
            }else if(i%2 != 0 && j%2 != 0){
                double aux = (this->get_pixel(x,y-1)+this->get_pixel(x+1,y)+this->get_pixel(x,y)+this->get_pixel(x+1,y-1));
                aux = round(aux/4); 
                zoom.set_pixel(i,j,aux); 
            }
                             
        }
        y = 0; 
        if ( i%2 != 0 ){
            x++;
        }
    } 

    return zoom; 
}

/*int Image::Redondeo(int n)const {
    if ( n % 2 >=  0.5){
        n++; 
    }
    return n; 
}*/

void Image::ShuffleRows() {
    const int p = 9973;
    Image temp(rows,cols);
    int newr;
    for (int r=0; r<rows; r++){
        newr = r*p % rows;
        for (int c=0; c<cols;c++)
            temp.set_pixel(r,c,get_pixel(newr,c));
    }
    Copy(temp);
}

//metodo para crear un icono
Image Image::Subsample(int factor) const{
    int filas = (this->get_rows() / factor); 
    int columnas = (this->get_cols() / factor); 
    Image icono(filas, columnas); 
    
    for(int i = 0; i < icono.get_rows(); i++){
        for(int j = 0; j < icono.get_cols(); j++){
            byte aux = ObtenerPixelIcono(i,j,factor);
            icono.set_pixel(i,j,aux);     
        }
    }
    
    return icono; 
}

//metodo para obtener el pixel de la imagen original sobre el factor de reduccion
byte Image::ObtenerPixelIcono(int fil, int col, int factor)const{
    long double aux = 0;  
    int area = factor*factor; 
    byte aux2;

    for(int i = fil * factor; i < fil * factor + factor; i++){
        for(int j = col * factor; j < col * factor + factor ; j++){
            aux += this->get_pixel(i,j); 
        }
    }
    aux = round(aux/area);  
    
    return aux; 
}

//Método para el contraste
void Image::AdjustContrast(byte in1, byte in2, byte out1, byte out2){
    double v; //nuValue;
    auto Vin1 = double(in1) , Vin2 = double(in2), Vout1 = double(out1), Vout2 = double(out2);
    double c1, c2, c3;
    c1 = (Vout1/Vin1);
    c2 = (Vout2-Vout1)/(Vin2- Vin1);
    c3 = (255 - Vout2)/(255 - Vin2);

    for (int i = 0; i <size(); i++){
        v = (double)get_pixel(i);
        if (v <= in1){          //Vemos en que espacio esta el pixel para hacer los debidos cambios
            this->set_pixel(i,(byte)round(c1*v));
        }
        else if (v <= in2){
            this->set_pixel(i,(byte)round(Vout1+(c2*(v-Vin1))));
        }
        else if(v <= 255){
            this->set_pixel(i,(byte)round(Vout2+(c3*(v-Vin2))));
        }
	else if(v == 0){
		this->set_pixel(i,(byte)0);
        }
	else{
		this->set_pixel(i,(byte)255);
        }
    }
}


